// Flarum Extension Setup
import app from 'flarum/app';
import { extend } from 'flarum/extend';
import Component from 'flarum/Component';
import Button from 'flarum/components/Button';

// Eklenti Başlığı ve Buton
app.initializers.add('xypp/store', () => {
  extend(Component.prototype, 'view', function () {
    // HTML içeriğini burada dinamik olarak render edeceğiz.
    return (
      <div className="store">
        <h2>Yerel Pazar</h2>
        <div className="product-list">
          {this.productList()}
        </div>
      </div>
    );
  });

  // Ürün Listesi Komponenti
  Component.prototype.productList = function () {
    // Bu örnek statik veridir, gerçek ürün verisi dinamik olarak alınabilir
    const products = [
      { name: 'Ürün 1', price: '100₺', description: 'Ürün açıklaması' },
      { name: 'Ürün 2', price: '150₺', description: 'Ürün açıklaması' },
    ];

    return (
      <div className="product-list">
        {products.map(product => (
          <div className="product-item" key={product.name}>
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <span>{product.price}</span>
            <Button className="buy-button">Satın Al</Button>
            <Button className="delete-button" onclick={this.deleteProduct}>Kaldır</Button>
          </div>
        ))}
      </div>
    );
  };

  // Ürün Silme İşlemi
  Component.prototype.deleteProduct = function () {
    // Burada ürün silme işlevselliği sağlanacak
    alert('Ürün kaldırıldı!');
  };
});
